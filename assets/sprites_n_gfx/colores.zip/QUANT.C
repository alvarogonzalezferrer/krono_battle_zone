// PROGRAMA MODIFICADO POR KRONOMAN
// TOMA DEFAULT.TGA (320x200x256) Y LE ADAPTA LA PALETA A UNA PALETA
// DE 4x64colores, sombreados en diferentes tonos oscuros.
// ES HIPER COOL!

/****************************************************************************/
/*                                                                          */
/*        QUANT.C, quantifies a 256-color tga image into 64 colors.         */
/*                                                                          */
/* It's done like this, loop through all pixels in the image.               */
/* Insert the 64 first different colors into quant_pal.                     */
/* When quant_pal is full, for each new color:                              */
/* find the color in quant_pal that is closest to the new color and change  */
/* that color to become a medium between it self and the new color.         */
/* All the time, record all color replaces in the array replace[256].       */
/* If it's working, when it's done all indexes in replace should be either  */
/* -1, that means there is no pixel with this index in the image, or a      */
/* number between 0 and 63 which is the replacement for that index.         */
/*                                                                          */
/*                    /Abe Racadabra, October 1996                          */
/*                                                                          */
/****************************************************************************/

#include <math.h>
#include "viewtga.c"

unsigned char pal[3*256];       /* the palette */
unsigned char quant_pal[3*64];  /* 64 quantified colors */
int replace[256];               /* replace array */
int max=0;      /* counter, number of quantified colors so far */

void setmode(int mode)
{
asm mov ax,[mode]
asm int 10h
}

/* check if color exists in quant_pal */
/* if it does, return color index, else return -1 */
int check_quant_pal(unsigned char color)
{
int i;
unsigned char r,g,b;
r=pal[3*color + 0];
g=pal[3*color + 1];
b=pal[3*color + 2];
for(i=0;i<max;i++)
if(quant_pal[3*i+0]==r && quant_pal[3*i+1]==g && quant_pal[3*i+2]==b)
return i;
return -1;
}

/* returns distance in color cube between 2 colors */
float get_dist(int r1, int r2, int g1, int g2, int b1, int b2)
{
return(sqrt((r2-r1)*(r2-r1)+(g2-g1)*(g2-g1)+(b2-b1)*(b2-b1)));
}

/* returns closest color in quant_pal compared to r,g,b */
int get_closest(unsigned char r, unsigned char g, unsigned char b)
{
int i,closest;
float dist,min_dist=100000;
for(i=0;i<max;i++)
{
	dist = get_dist(quant_pal[3*i+0],r,quant_pal[3*i+1],g,quant_pal[3*i+2],b);
	if(dist<min_dist)
	{
		min_dist = dist;
		closest = i;
	}
}
return closest;
}

/* inserts a color into quant_pal */
void insert(unsigned char color)
{
int check,closest;
unsigned char r,g,b;
r=pal[3*color + 0];
g=pal[3*color + 1];
b=pal[3*color + 2];

check = check_quant_pal(color); /* check if it's alreadey there */
if(check != -1)
{
	replace[color] = check; /*color exists, just insert in replace */
}
else    /* color is new, insert into quant_pal */
{
	if(max<63)      /* all colors not filled, just insert in quant_pal */
	{
		quant_pal[3*max+0] = r;
		quant_pal[3*max+1] = g;
		quant_pal[3*max+2] = b;
		replace[color] = max;
		max++;
	}
	else    /* new color and quant_pal is full */
	{
		closest = get_closest(r,g,b);
		/* median between quant_pal[closest] and r,g,b */
		quant_pal[3*closest+0] = (quant_pal[3*closest+0]+r)/2;
		quant_pal[3*closest+1] = (quant_pal[3*closest+1]+g)/2;
		quant_pal[3*closest+2] = (quant_pal[3*closest+2]+b)/2;
		replace[color] = closest;
	}
}
}

/* increase blue, decrease red and green */
void blueshades(void)
{
int i,distb;
for(i=0;i<64;i++)
{
	distb=63-pal[3*i+2];    /* distance to full blue */

	/* shade 1, a little bluish */
	pal[3*i+0+64*3] = pal[3*i+0]*0.8;
	pal[3*i+1+64*3] = pal[3*i+1]*0.8;
	pal[3*i+2+64*3] = pal[3*i+2] + distb*0.2;

	/* shade 2, more bluish */
	pal[3*i+0+128*3] = pal[3*i+0]*0.6;
	pal[3*i+1+128*3] = pal[3*i+1]*0.6;
	pal[3*i+2+128*3] = pal[3*i+2] + distb*0.3;

	/* shade 3, most bluish */
	pal[3*i+0+192*3] = pal[3*i+0]*0.5;
	pal[3*i+1+192*3] = pal[3*i+1]*0.5;
	pal[3*i+2+192*3] = pal[3*i+2] + distb*0.5;
}
}

/* decrease all, decrease red and blue more than green */
void greenshades(void)
{
int i;
for(i=0;i<64;i++)
{

	/* shade 1, a little green */
	pal[3*i+0+64*3] = pal[3*i+0]*0.7;
	pal[3*i+1+64*3] = pal[3*i+1]*0.9;
	pal[3*i+2+64*3] = pal[3*i+2]*0.7;

	/* shade 2, more green */
	pal[3*i+0+128*3] = pal[3*i+0]*0.5;
	pal[3*i+1+128*3] = pal[3*i+1]*0.8;
	pal[3*i+2+128*3] = pal[3*i+2]*0.5;

	/* shade 3, most green */
	pal[3*i+0+192*3] = pal[3*i+0]*0.3;
	pal[3*i+1+192*3] = pal[3*i+1]*0.7;
	pal[3*i+2+192*3] = pal[3*i+2]*0.3;
}
}


/* increase all towards white */
void fogshades(void)
{
int i,distr,distg,distb;
for(i=0;i<64;i++)
{
	distr=63-pal[3*i+0];    /* distance to full red */
	distg=63-pal[3*i+1];    /* distance to full green */
	distb=63-pal[3*i+2];    /* distance to full blue */

	/* shade 1, a little foggy */
	pal[3*i+0+64*3] = pal[3*i+0] + distr*0.3;
	pal[3*i+1+64*3] = pal[3*i+1] + distg*0.3;
	pal[3*i+2+64*3] = pal[3*i+2] + distb*0.3;

	/* shade 2, more foggy */
	pal[3*i+0+128*3] = pal[3*i+0] + distr*0.5;
	pal[3*i+1+128*3] = pal[3*i+1] + distg*0.5;
	pal[3*i+2+128*3] = pal[3*i+2] + distb*0.5;

	/* shade 3, most foggy */
	pal[3*i+0+192*3] = pal[3*i+0] + distr*0.7;
	pal[3*i+1+192*3] = pal[3*i+1] + distg*0.7;
	pal[3*i+2+192*3] = pal[3*i+2] + distb*0.7;
}
}

// Rutina por KRONOMAN
// decrementa todo hacia el negro
void darkshades(void)
{
int i,distr,distg,distb;
for(i=0;i<64;i++)
{
	distr=63-pal[3*i+0];    /* distance to full red */
	distg=63-pal[3*i+1];    /* distance to full green */
	distb=63-pal[3*i+2];    /* distance to full blue */

        // sombra 1 - algo oscuro
        pal[3*i+0+64*3] = pal[3*i+0] * 0.9;
        pal[3*i+1+64*3] = pal[3*i+1] * 0.9;
        pal[3*i+2+64*3] = pal[3*i+2] * 0.9;

        // sombra 2, mas oscuro
        pal[3*i+0+128*3] = pal[3*i+0] * 0.5;
        pal[3*i+1+128*3] = pal[3*i+1] * 0.5;
        pal[3*i+2+128*3] = pal[3*i+2] * 0.5;

        // shade 4 todo oscuro 
        pal[3*i+0+192*3] = pal[3*i+0] * 0.3;
        pal[3*i+1+192*3] = pal[3*i+1] * 0.3;
        pal[3*i+2+192*3] = pal[3*i+2] * 0.3;
}
}



/* replaces all pixels on the screen with the quantified colors 0..63 */
void do_replace(void)
{
int x,y;
for(y=0;y<200;y++)
for(x=0;x<320;x++)
putpixel(x,y,replace[getpixel(x,y)]);

for(x=0;x<3*64;x++)pal[x]=quant_pal[x];
// blueshades();
// fogshades();
// greenshades();
darkshades();

setpal(pal);
}

/* quantifies picture to 64 colors using current palette */
void quant(void)
{
int x,y;
unsigned char color;
for(x=0;x<256;x++) replace[x]=-1;
for(y=0;y<200;y++)
for(x=0;x<320;x++)
{
	color = getpixel(x,y);
	if(replace[color] == -1) insert(color);
}
do_replace();
}

/* draw the shades in stripes over the screen */
void fourway(void)
{
int x,y;
for(y=50;y<100;y++)     /* shade 1 */
for(x=0;x<320;x++)
putpixel(x,y,getpixel(x,y)+64);
for(y=100;y<150;y++)    /* shade 2 */
for(x=0;x<320;x++)
putpixel(x,y,getpixel(x,y)+128);
for(y=150;y<200;y++)    /* shade 3 */
for(x=0;x<320;x++)
putpixel(x,y,getpixel(x,y)+192);
}

void main(void)
{
setmode(0x013);
ViewTgaNGetPal("default.tga",pal); /* view the tga-picture */
getch();
quant();        /* quantify into 64 colors and */
getch();        /* make the rest of the palette blue shades */

/* you could save the screen and palette into a .pic and a .pal file here */

fourway();      /* draw the shades in stripes across the screen */
getch();        /* to make sure it really works */
setmode(3);
}
